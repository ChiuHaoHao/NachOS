// scheduler.cc
//	Routines to choose the next thread to run, and to dispatch to
//	that thread.
//
// 	These routines assume that interrupts are already disabled.
//	If interrupts are disabled, we can assume mutual exclusion
//	(since we are on a uniprocessor).
//
// 	NOTE: We can't use Locks to provide mutual exclusion here, since
// 	if we needed to wait for a lock, and the lock was busy, we would
//	end up calling FindNextToRun(), and that would put us in an
//	infinite loop.
//
// 	Very simple implementation -- no priorities, straight FIFO.
//	Might need to be improved in later assignments.
//
// Copyright (c) 1992-1996 The Regents of the University of California.
// All rights reserved.  See copyright.h for copyright notice and limitation
// of liability and disclaimer of warranty provisions.

#include "copyright.h"
#include "debug.h"
#include "scheduler.h"
#include "main.h"

//----------------------------------------------------------------------
// Scheduler::Scheduler
// 	Initialize the list of ready but not running threads.
//	Initially, no ready threads.
//----------------------------------------------------------------------

Scheduler::Scheduler()
{
    readyList = new List<Thread *>;
    L1 = new List<Thread *>;
    L2 = new List<Thread *>;
    L3 = new List<Thread *>;
    toBeDestroyed = NULL;
}

//----------------------------------------------------------------------
// Scheduler::~Scheduler
// 	De-allocate the list of ready threads.
//----------------------------------------------------------------------

Scheduler::~Scheduler()
{
    delete readyList;
    delete L1;
    delete L2;
    delete L3;
}

void Scheduler::PushIntoQueue(List<Thread *> *levelQueue, Thread *newThread)
{
    levelQueue->Append(newThread);
    // cout << "Push into Queue" << endl;
    // Print();
}

void Scheduler::RemoveFromQueue(List<Thread *> *levelQueue, Thread *newThread)
{
    levelQueue->Remove(newThread);
    // cout << "Remove from Queue" << endl;
    // Print();
    newThread->calculateAgingTick();
    newThread->threadAgingTick = kernel->stats->totalTicks;
}

//----------------------------------------------------------------------
// Scheduler::ReadyToRun
// 	Mark a thread as ready, but not running.
//	Put it on the ready list, for later scheduling onto the CPU.
//
//	"thread" is the thread to be put on the ready list.
//----------------------------------------------------------------------

void Scheduler::ReadyToRun(Thread *thread)
{
    ASSERT(kernel->interrupt->getLevel() == IntOff);
    DEBUG(dbgThread, "Putting thread on ready list: " << thread->getName());

    //cout << "Putting thread on ready list: " << thread->getName() << endl ;
    thread->setStatus(READY);
    // readyList->Append(thread);
    int currentPriority = thread->GetPriority();
    if (currentPriority >= 100)
    {
        thread->level = 1;
        PushIntoQueue(L1, thread);
    }
    else if (currentPriority >= 50 && currentPriority <= 99)
    {
        thread->level = 2;
        PushIntoQueue(L2, thread);
    }
    else
    {
        thread->level = 3;
        PushIntoQueue(L3, thread);      
    }
    DEBUG(dbgExpr, "[A] Tick [" << kernel->stats->totalTicks << "] : Thread [" << thread->getID() << "] is inserted into queue [" << thread->level << "]");
    thread->threadAgingTick = kernel->stats->totalTicks;
    // Print();
}

//----------------------------------------------------------------------
// Scheduler::FindNextToRun
// 	Return the next thread to be scheduled onto the CPU.
//	If there are no ready threads, return NULL.
// Side effect:
//	Thread is removed from the ready list.
//----------------------------------------------------------------------

Thread *
Scheduler::FindNextToRun()
{
    ASSERT(kernel->interrupt->getLevel() == IntOff);
    // Print();
    if (!L1->IsEmpty())
    {
        // Preemptive SJF
        // need to go through the list, find the thread has lowest guessTime
        ListIterator<Thread *> *iter;
        iter = new ListIterator<Thread *>(L1);
        Thread *targetThread = L1->Front(); // Assign default value (The first element) to prevent segmentation fault
        double minGuessTime = targetThread->guessTime;
        while (!iter->IsDone())
        {
            Thread *iterThread;
            iterThread = iter->Item();
            if (iterThread->guessTime < minGuessTime)
            {
                targetThread = iterThread;
                minGuessTime = iterThread->guessTime;
            }
            iter->Next();
        }
        // Remove from queue, put it into scheduler
        RemoveFromQueue(L1, targetThread);
        DEBUG(dbgExpr, "[B] Tick [" << kernel->stats->totalTicks << "] : Thread [" << targetThread->getID() << "] is removed from queue [" << targetThread->level << "]");
        return targetThread;
    }
    else if (!L2->IsEmpty())
    {
        // Non-preemptive priority
        ListIterator<Thread *> *iter;
        iter = new ListIterator<Thread *>(L2);
        Thread *targetThread = L2->Front(); // Assign default value (The first element) to prevent segmentation fault
        int maxPriority = targetThread->GetPriority();
        while (!iter->IsDone())
        {
            Thread *iterThread;
            iterThread = iter->Item();
            if (iterThread->GetPriority() > maxPriority)
            {
                targetThread = iterThread;
                maxPriority = iterThread->GetPriority();
            }
            iter->Next();
        }
        RemoveFromQueue(L2, targetThread);
        DEBUG(dbgExpr, "[B] Tick [" << kernel->stats->totalTicks << "] : Thread [" << targetThread->getID() << "] is removed from queue [" << targetThread->level << "]");
        return targetThread;
    }
    else if (!L3->IsEmpty())
    {
        // Round-robin
        Thread *targetThread = L3->Front(); // Assign default value (The first element) to prevent segmentation fault
        RemoveFromQueue(L3, targetThread);
        DEBUG(dbgExpr, "[B] Tick [" << kernel->stats->totalTicks << "] : Thread [" << targetThread->getID() << "] is removed from queue [" << targetThread->level << "]");
        return targetThread;
    }
    else
    {
        return NULL;
    }
}

//----------------------------------------------------------------------
// Scheduler::Run
// 	Dispatch the CPU to nextThread.  Save the state of the old thread,
//	and load the state of the new thread, by calling the machine
//	dependent context switch routine, SWITCH.
//
//      Note: we assume the state of the previously running thread has
//	already been changed from running to blocked or ready (depending).
// Side effect:
//	The global variable kernel->currentThread becomes nextThread.
//
//	"nextThread" is the thread to be put into the CPU.
//	"finishing" is set if the current thread is to be deleted
//		once we're no longer running on its stack
//		(when the next thread starts running)
//----------------------------------------------------------------------

void Scheduler::Run(Thread *nextThread, bool finishing)
{
    Thread *oldThread = kernel->currentThread;

    ASSERT(kernel->interrupt->getLevel() == IntOff);

    if (finishing)
    { // mark that we need to delete current thread
        ASSERT(toBeDestroyed == NULL);
        toBeDestroyed = oldThread;
    }

    if (oldThread->space != NULL)
    {                               // if this thread is a user program,
        oldThread->SaveUserState(); // save the user's CPU registers
        oldThread->space->SaveState();
    }

    oldThread->CheckOverflow(); // check if the old thread
                                // had an undetected stack overflow

    kernel->currentThread = nextThread; // switch to the next thread
    nextThread->setStatus(RUNNING);     // nextThread is now running
    nextThread->threadInitialBurstTick = kernel->stats->totalTicks;

    DEBUG(dbgThread, "Switching from: " << oldThread->getName() << " to: " << nextThread->getName());
    DEBUG(dbgExpr, "[E] Tick [" << kernel->stats->totalTicks << "] Thread [" << nextThread->getID() << "] is now selected for execution, thread [" << oldThread->getID() << "] is replaced, and it has executed [" << kernel->stats->totalTicks - oldThread->threadInitialBurstTick << "] ticks");

    // This is a machine-dependent assembly language routine defined
    // in switch.s.  You may have to think
    // a bit to figure out what happens after this, both from the point
    // of view of the thread and from the perspective of the "outside world".

    SWITCH(oldThread, nextThread);

    // we're back, running oldThread
    oldThread->threadInitialBurstTick = kernel->stats->totalTicks;
    // interrupts are off when we return from switch!
    ASSERT(kernel->interrupt->getLevel() == IntOff);

    DEBUG(dbgThread, "Now in thread: " << oldThread->getName());

    CheckToBeDestroyed(); // check if thread we were running
                          // before this one has finished
                          // and needs to be cleaned up

    if (oldThread->space != NULL)
    {                                  // if there is an address space
        oldThread->RestoreUserState(); // to restore, do it.
        oldThread->space->RestoreState();
    }
}

//----------------------------------------------------------------------
// Scheduler::CheckToBeDestroyed
// 	If the old thread gave up the processor because it was finishing,
// 	we need to delete its carcass.  Note we cannot delete the thread
// 	before now (for example, in Thread::Finish()), because up to this
// 	point, we were still running on the old thread's stack!
//----------------------------------------------------------------------

void Scheduler::CheckToBeDestroyed()
{
    if (toBeDestroyed != NULL)
    {
        delete toBeDestroyed;
        toBeDestroyed = NULL;
    }
}

//----------------------------------------------------------------------
// Scheduler::Print
// 	Print the scheduler state -- in other words, the contents of
//	the ready list.  For debugging.
//----------------------------------------------------------------------
void Scheduler::Print()
{
    // cout << "Ready list contents:\n";
    // readyList->Apply(ThreadPrint);
    cout << "Ready list contents in L1:\n";
    L1->Apply(ThreadPrint);
    cout << "Ready list contents in L2:\n";
    L2->Apply(ThreadPrint);
    cout << "Ready list contents in L3:\n";
    L3->Apply(ThreadPrint);
    cout << "\n";
}

bool Scheduler::checkL1()
{
    if (L1->IsEmpty())
        return false;
    else
        return true;
}

void Scheduler::CallAging() {
    Aging(L3, 3);
    Aging(L2, 2);
    Aging(L1, 1);
    // Aging(&L3, 3);
    // Aging(&L2, 2);
    // Aging(&L1, 1);
    // Print();
}

void Scheduler::Aging(List<Thread *> *level_queue, int level) {
    ASSERT(kernel->interrupt->getLevel() == IntOff);

    ListIterator<Thread *> *iter;
    iter = new ListIterator<Thread *>(level_queue);
    List<Thread *> *new_level_queue = new List<Thread *>;

    while (!iter->IsDone()) {
        Thread *iterThread;
        iterThread = iter->Item();
        iterThread->calculateAgingTick();
        iterThread->threadAgingTick = kernel->stats->totalTicks;
        bool moreThanAgeTime = iterThread->aging >= 1500;
        bool isPush = false;
        if (moreThanAgeTime && iterThread->GetPriority() < 149) {
            iterThread->aging -= 1500;
            int oldPriority = iterThread->GetPriority();
            int newPriority = (oldPriority < 140) ? oldPriority + 10 : 149;
            DEBUG(dbgExpr, "[C] Tick [" << kernel->stats->totalTicks << "] : Thread [" << iterThread->getID() << "] changes its priority from  [" << oldPriority << "] to [" << newPriority << "]");
            iterThread->SetPriority(newPriority);
            if (level == 1) {

            }
            else if (level == 2 && iterThread->GetPriority() >= 100) {
                PushIntoQueue(L1, iterThread);
                iterThread->level = 1;
                isPush = true;
                // iterThread->calculateAgingTick();
                // iterThread->threadAgingTick = kernel->stats->totalTicks;
            }  
            else if (level == 3 && iterThread->GetPriority() >= 50) {
                PushIntoQueue(L2, iterThread);
                iterThread->level = 2;
                isPush = true;
                // iterThread->calculateAgingTick();
                // iterThread->threadAgingTick = kernel->stats->totalTicks;
            }
        }
        // else {
        if (!isPush)
            PushIntoQueue(new_level_queue, iterThread);
        // }
        iter->Next();
    }
    // cout << "Aging" << endl;
    // L3->Apply(ThreadPrint);
    if (level == 1) {
        delete L1;
        L1 = new_level_queue;
    }
    else if (level == 2) {
        delete L2;
        L2 = new_level_queue;
    }
    else if (level == 3) {
        delete L3;
        L3 = new_level_queue;
    }
    // delete *level_queue;
    // *level_queue = new_level_queue;
}

bool Scheduler::checkIfYield() {
    ASSERT(kernel->interrupt->getLevel() == IntOff);
    
    if (kernel->currentThread->level == 3) 
        return true;
    bool hasThreadInL1 = kernel->scheduler->checkL1();
    if (hasThreadInL1) 
        return true;
    return false;
}

// bool Scheduler::checkIfYield() {
//     ASSERT(kernel->interrupt->getLevel() == IntOff);
    
//     if (kernel->currentThread->level == 3) 
//         return true;
//     bool hasThreadInL1 = kernel->scheduler->checkL1();
//     if (hasThreadInL1) {
//         if (kernel->currentThread->level != 1) 
//             return true;
        
//         ListIterator<Thread *> *iter;
//         iter = new ListIterator<Thread *>(L1);
//         double GuessTime = kernel->currentThread->guessTime;
//         while (!iter->IsDone())
//         {
//             Thread *iterThread;
//             iterThread = iter->Item();
//             if (iterThread->guessTime < GuessTime)
//                 return true;
//             iter->Next();
//         }
//     }
//     return false;
// }