// filehdr.cc
//  Routines for managing the disk file header (in UNIX, this
//  would be called the i-node).
//
//  The file header is used to locate where on disk the
//  file's data is stored.  We implement this as a fixed size
//  table of pointers -- each entry in the table points to the
//  disk sector containing that portion of the file data
//  (in other words, there are no indirect or doubly indirect
//  blocks). The table size is chosen so that the file header
//  will be just big enough to fit in one disk sector,
//
//      Unlike in a real system, we do not keep track of file permissions,
//  ownership, last modification date, etc., in the file header.
//
//  A file header can be initialized in two ways:
//     for a new file, by modifying the in-memory data structure
//       to point to the newly allocated data blocks
//     for a file already on disk, by reading the file header from disk
//
// Copyright (c) 1992-1993 The Regents of the University of California.
// All rights reserved.  See copyright.h for copyright notice and limitation
// of liability and disclaimer of warranty provisions.

#include "copyright.h"

#include "filehdr.h"
#include "debug.h"
#include "synchdisk.h"
#include "main.h"

//----------------------------------------------------------------------
// MP4 mod tag
// FileHeader::FileHeader
//  There is no need to initialize a fileheader,
//  since all the information should be initialized by Allocate or FetchFrom.
//  The purpose of this function is to keep valgrind happy.
//----------------------------------------------------------------------
FileHeader::FileHeader()
{
	numBytes = -1;
	numSectors = -1;
	memset(dataSectors, -1, sizeof(dataSectors));
}

//----------------------------------------------------------------------
// MP4 mod tag
// FileHeader::~FileHeader
//  Currently, there is not need to do anything in destructor function.
//  However, if you decide to add some "in-core" data in header
//  Always remember to deallocate their space or you will leak memory
//----------------------------------------------------------------------
FileHeader::~FileHeader()
{
	// nothing to do now
}

// two level for 30 * 128 = 3840
// three level for 30 * 30 * 128 = 115200
// four level for 30 * 30 * 30 * 128 = 3456000
#define filesize_level2 (NumDirect * SectorSize)
#define filesize_level3 (NumDirect * NumDirect * SectorSize)
#define filesize_level4 (NumDirect * NumDirect * NumDirect * SectorSize)

//----------------------------------------------------------------------
// FileHeader::Allocate
//  Initialize a fresh file header for a newly created file.
//  Allocate data blocks for the file out of the map of free disk blocks.
//  Return FALSE if there are not enough free blocks to accomodate
//  the new file.
//
//  "freeMap" is the bit map of free disk sectors
//  "fileSize" is the bit map of free disk sectors
//----------------------------------------------------------------------
int FileHeader::check_level(int fileSize, int level)
{
	if (fileSize > level)
	{
		return 1;
	}
	else
	{
		return 0;
	}
}

bool FileHeader::Allocate(PersistentBitmap *freeMap, int fileSize)
{
	numBytes = fileSize;
	numSectors = divRoundUp(fileSize, SectorSize);
	if (freeMap->NumClear() < numSectors)
		return FALSE; // not enough space

	// implement multilevel scheme
	// fileSize > 3840 bytes use two level
	// bonus use four level
	if (fileSize > filesize_level4)
	{
		int idx = 0;
		while (fileSize > 0)
		{
			dataSectors[idx] = freeMap->FindAndSet();
			ASSERT(dataSectors[idx] >= 0);

			FileHeader *subHdr = new FileHeader;
			int exceed = check_level(fileSize, filesize_level4);
			(exceed) ? subHdr->Allocate(freeMap, filesize_level4) : subHdr->Allocate(freeMap, fileSize);
			fileSize = (exceed) ? fileSize - filesize_level4 : 0;
			numSectors = idx;
			subHdr->WriteBack(dataSectors[idx]);
			delete subHdr;
			idx++;
		}
	}
	else if (fileSize > filesize_level3)
	{
		int idx = 0;
		while (fileSize > 0)
		{
			dataSectors[idx] = freeMap->FindAndSet();
			ASSERT(dataSectors[idx] >= 0);

			FileHeader *subHdr = new FileHeader;
			int exceed = check_level(fileSize, filesize_level3);
			(exceed) ? subHdr->Allocate(freeMap, filesize_level3) : subHdr->Allocate(freeMap, fileSize);
			fileSize = (exceed) ? fileSize - filesize_level3 : 0;
			numSectors = idx;
			subHdr->WriteBack(dataSectors[idx]);
			delete subHdr;
			idx++;
		}
	}
	else if (fileSize > filesize_level2)
	{
		int idx = 0;
		while (fileSize > 0)
		{
			dataSectors[idx] = freeMap->FindAndSet();
			ASSERT(dataSectors[idx] >= 0);

			FileHeader *subHdr = new FileHeader;
			int exceed = check_level(fileSize, filesize_level2);
			(exceed) ? subHdr->Allocate(freeMap, filesize_level2) : subHdr->Allocate(freeMap, fileSize);
			fileSize = (exceed) ? fileSize - filesize_level2 : 0;
			numSectors = idx;
			subHdr->WriteBack(dataSectors[idx]);
			delete subHdr;
			idx++;
		}
	}
	else
	{
		for (int i = 0; i < numSectors; i++)
		{
			dataSectors[i] = freeMap->FindAndSet();
			ASSERT(dataSectors[i] >= 0);
		}
	}
	return TRUE;
}

void FileHeader::nowHeaderSize()
{
	if (this->numBytes > filesize_level4)
	{
		printf("This file is allocate at Level4!\n");
	}
	else if (this->numBytes > filesize_level3)
	{
		printf("This file is allocate at Level3!\n");
	}
	else if (this->numBytes > filesize_level2)
	{
		printf("This file is allocate at Level2!\n");
	}
	else
	{
		printf("This file is allocate at Level1!\n");
	}
	
}

//----------------------------------------------------------------------
// FileHeader::Deallocate
//  De-allocate all the space allocated for data blocks for this file.
//
//  "freeMap" is the bit map of free disk sectors
//----------------------------------------------------------------------

void FileHeader::Deallocate(PersistentBitmap *freeMap)
{
	if (numBytes < filesize_level2)
	{
		for (int i = 0; i < numSectors; i++)
		{
			ASSERT(freeMap->Test((int)dataSectors[i])); // ought to be marked!
			freeMap->Clear((int)dataSectors[i]);
		}
	}
	else
	{
		for (int i = 0; i < numSectors; i++)
		{
			FileHeader *deFile = new FileHeader;
			deFile->FetchFrom(dataSectors[i]);
			deFile->Deallocate(freeMap);
			freeMap->Clear((int)dataSectors[i]);
			delete deFile;
		}
	}
}

//----------------------------------------------------------------------
// FileHeader::FetchFrom
//  Fetch contents of file header from disk.
//
//  "sector" is the disk sector containing the file header
//----------------------------------------------------------------------

void FileHeader::FetchFrom(int sector)
{
	kernel->synchDisk->ReadSector(sector, (char *)this);

	/*
    MP4 Hint:
    After you add some in-core informations, you will need to rebuild the header's structure
  */
}

//----------------------------------------------------------------------
// FileHeader::WriteBack
//  Write the modified contents of the file header back to disk.
//
//  "sector" is the disk sector to contain the file header
//----------------------------------------------------------------------

void FileHeader::WriteBack(int sector)
{
	kernel->synchDisk->WriteSector(sector, (char *)this);

	/*
    MP4 Hint:
    After you add some in-core informations, you may not want to write all fields into disk.
    Use this instead:
    char buf[SectorSize];
    memcpy(buf + offset, &dataToBeWritten, sizeof(dataToBeWritten));
    ...
  */
}

//----------------------------------------------------------------------
// FileHeader::ByteToSector
//  Return which disk sector is storing a particular byte within the file.
//      This is essentially a translation from a virtual address (the
//  offset in the file) to a physical address (the sector where the
//  data at the offset is stored).
//
//  "offset" is the location within the file of the byte in question
//----------------------------------------------------------------------
void FileHeader::ByteToSectorConverter(int fileLevel, int offset)
{
	FileHeader *fheader = new FileHeader;
	int sector = divRoundDown(offset, fileLevel);
	fheader->FetchFrom(dataSectors[sector]);
	fheader->ByteToSector(offset - sector * fileLevel);
}

int FileHeader::ByteToSector(int offset)
{
	if (numBytes > filesize_level4)
	{
		ByteToSectorConverter(filesize_level4, offset);
	}
	else if (numBytes > filesize_level3)
	{
		ByteToSectorConverter(filesize_level3, offset);
	}
	else if (numBytes > filesize_level2)
	{
		ByteToSectorConverter(filesize_level2, offset);
	}
	else
	{
		return (dataSectors[offset / SectorSize]);
	}
}

//----------------------------------------------------------------------
// FileHeader::FileLength
//  Return the number of bytes in the file.
//----------------------------------------------------------------------

int FileHeader::FileLength()
{
	return numBytes;
}

//----------------------------------------------------------------------
// FileHeader::Print
//  Print the contents of the file header, and the contents of all
//  the data blocks pointed to by the file header.
//----------------------------------------------------------------------

void FileHeader::Print()
{
	int i, j, k;
	char *data = new char[SectorSize];

	printf("FileHeader contents.  File size: %d.  File blocks:\n", numBytes);
	if (numBytes > filesize_level2)
	{
		for (i = 0; i < numSectors; i++)
		{
			FileHeader *fh = new FileHeader;
			fh->FetchFrom(dataSectors[i]);
			fh->Print();
		}
	}
	else
	{
		for (i = 0; i < numSectors; i++)
			printf("%d ", dataSectors[i]);
		printf("\nFile contents:\n");
		for (i = k = 0; i < numSectors; i++)
		{
			kernel->synchDisk->ReadSector(dataSectors[i], data);
			for (j = 0; (j < SectorSize) && (k < numBytes); j++, k++)
			{
				if ('\040' <= data[j] && data[j] <= '\176') // isprint(data[j])
					printf("%c", data[j]);
				else
					printf("\\%x", (unsigned char)data[j]);
			}
			printf("\n");
		}
		delete[] data;
	}
}

void FileHeader::PrintSector()
{
	int i;
	if (numBytes > filesize_level2)
	{
		for (i = 0; i < numSectors; i++)
		{
			printf("%d ", dataSectors[i]);
			FileHeader *hdr = new FileHeader;
			hdr->FetchFrom(dataSectors[i]);
			hdr->PrintSector();
		}
		printf("\n");
		printf("========================================================\n");
	}
}

	// //----------------------------------------------------------------------
	// // FileHeader::Print
	// //  Print the contents of the file header, and the contents of all
	// //  the data blocks pointed to by the file header.
	// //----------------------------------------------------------------------

	// void FileHeader::Print()
	// {
	// 	int i, j, k;
	// 	char *data = new char[SectorSize];

	// 	printf("FileHeader contents.  File size: %d.  File blocks:\n", numBytes);
	// 	for (i = 0; i < numSectors; i++)
	// 		printf("%d ", dataSectors[i]);
	// 	printf("\nFile contents:\n");
	// 	for (i = k = 0; i < numSectors; i++)
	// 	{
	// 		kernel->synchDisk->ReadSector(dataSectors[i], data);
	// 		for (j = 0; (j < SectorSize) && (k < numBytes); j++, k++)
	// 		{
	// 			if ('\040' <= data[j] && data[j] <= '\176') // isprint(data[j])
	// 				printf("%c", data[j]);
	// 			else
	// 				printf("\\%x", (unsigned char)data[j]);
	// 		}
	// 		printf("\n");
	// 	}
	// 	delete[] data;
	// }
