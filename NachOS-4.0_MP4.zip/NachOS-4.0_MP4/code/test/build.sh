cd ../build.linux
make clean
make