/**************************************************************
 *
 * userprog/ksyscall.h
 *
 * Kernel interface for systemcalls 
 *
 * by Marcus Voelp  (c) Universitaet Karlsruhe
 *
 **************************************************************/

#ifndef __USERPROG_KSYSCALL_H__
#define __USERPROG_KSYSCALL_H__

#include "kernel.h"

#include "synchconsole.h"

void SysHalt()
{
    kernel->interrupt->Halt();
}

int SysAdd(int op1, int op2)
{
    return op1 + op2;
}
// m
int SysCreate(char *filename, int filesize)
{
    bool crt_scs; // create successfully
    crt_scs = kernel->fileSystem->Create(filename, filesize);
    return 1; // always success & return 1
}

OpenFileId SysOpen(char *name)
{
    kernel->fileSystem->currentFile = kernel->fileSystem->Open(name);
    if (kernel->fileSystem->Open(name) != NULL)
        return 1;
    else
        return 0;
}
int SysRead(char *buf, int size, OpenFileId id)
{
    return kernel->fileSystem->currentFile->Read(buf, size); // id always valid
}
int SysWrite(char *buf, int size, OpenFileId id)
{
    return kernel->fileSystem->currentFile->Write(buf, size);
}
int SysClose(OpenFileId id)
{
    delete kernel->fileSystem->currentFile;
    return 1; // always success & return 1
}
// m
#ifdef FILESYS_STUB
int SysCreate(char *filename)
{
    // return value
    // 1: success
    // 0: failed
    return kernel->interrupt->CreateFile(filename);
}
#endif

#endif /* ! __USERPROG_KSYSCALL_H__ */
